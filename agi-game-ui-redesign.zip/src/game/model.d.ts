export const M: any;
